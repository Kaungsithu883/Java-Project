package strutsaction;

import java.util.Map;
import org.apache.struts2.dispatcher.SessionMap;
import org.apache.struts2.interceptor.SessionAware;

import dao.LoginDao;



public class LoginAction implements SessionAware{
private String uemail,upass;
SessionMap<String,String> sessionmap;

public String getuemail() {
	return uemail;
}

public void setuemail(String uemail) {
	this.uemail = uemail;
}

public String getupass() {
	return upass;
}

public void setupass(String upass) {
	this.upass = upass;
}

public String execute(){
	if(LoginDao.validate(uemail, upass)){
		return "success";
	}
	else{
		return "error";
	}
}


public void setSession(Map map) {
	sessionmap=(SessionMap)map;
	sessionmap.put("login","true");
}

public String logout(){
	sessionmap.invalidate();
	return "success";
}

}
