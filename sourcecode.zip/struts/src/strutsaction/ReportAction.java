package strutsaction;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import bean.StrutsBean;
import dao.StrutsDao;

import com.opensymphony.xwork2.ActionSupport;
public class ReportAction extends ActionSupport {

	private static final long serialVersionUID = 1L;
	ResultSet rs = null;
	StrutsBean bean = null;
	List<StrutsBean> beanList = null;
	StrutsDao admin = new StrutsDao();
	private boolean noData = false;

	@Override
	public String execute() throws Exception {
		try {
			beanList = new ArrayList<StrutsBean>();
			rs = admin.report();
			int i = 0;
			if (rs != null) {
				while (rs.next()) {
					i++;
				    bean = new StrutsBean();
					bean.setSrNo(i);
					bean.setuname(rs.getString("uname"));
					bean.setuemail(rs.getString("uemail"));
					bean.setupass(rs.getString("upass").replaceAll("(?s).", "*"));
					bean.setudeg(rs.getString("udeg"));
					beanList.add(bean);
				}
			}
			if (i == 0) {
				noData = false;
			} else {
				noData = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "REPORT";
	}

	public boolean isNoData() {
		return noData;
	}

	public void setNoData(boolean noData) {
		this.noData = noData;
	}

	public List<StrutsBean> getBeanList() {
		return beanList;
	}

	public void setBeanList(List<StrutsBean> beanList) {
		this.beanList = beanList;
	}
}

	


