package strutsaction;

import java.sql.ResultSet;

import com.opensymphony.xwork2.ActionSupport;

import dao.StrutsDao;

public class UpdateAction extends ActionSupport{
	
	private static final long serialVersionUID = 1L;
	private String uname = "", fname = "",lname = "", city = "", country = "", uemail = "", upass = "", udeg = "", uemailhidden = "";
	private String msg = "";
	ResultSet rs = null;
	StrutsDao dao = new StrutsDao();
	String submitType;

	@Override
	public String execute() throws Exception {
		try {
			if (submitType.equals("updatedata")) {
				rs = dao.fetchUserDetails(uemail.trim());
				if (rs != null) {
					while (rs.next()) {
						uname = rs.getString("uname");
						fname = rs.getString("fname");
						lname = rs.getString("lname");
						city = rs.getString("city");
						country = rs.getString("country");
						uemail = rs.getString("uemail");
						upass = rs.getString("upass");
						udeg = rs.getString("udeg");
					}
				}
			} else {
				int i = dao.updateUserDetails(uname, fname, lname, city, country, uemail, upass, udeg, uemailhidden);
				if (i > 0) {
					msg = "Record Updated Successfuly";
				} else {
					msg = "error";
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return "UPDATE";
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}
	
	public String getfname() {
		return fname;
	}

	public void setfname(String fname) {
		this.fname = fname;
	}
	
	public String getlname() {
		return lname;
	}

	public void setlname(String lname) {
		this.lname = lname;
	}
	
	public String getcity() {
		return city;
	}

	public void setcity(String city) {
		this.city = city;
	}
	
	public String getcountry() {
		return country;
	}

	public void setcountry(String country) {
		this.country = country;
	}

	public String getUpass() {
		return upass;
	}

	public void setUpass(String upass) {
		this.upass = upass;
	}

	public String getUdeg() {
		return udeg;
	}

	public void setUdeg(String udeg) {
		this.udeg = udeg;
	}

	public String getUemail() {
		return uemail;
	}

	public void setUemail(String uemail) {
		this.uemail = uemail;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getUemailhidden() {
		return uemailhidden;
	}

	public void setUemailhidden(String uemailhidden) {
		this.uemailhidden = uemailhidden;
	}

	public String getSubmitType() {
		return submitType;
	}

	public void setSubmitType(String submitType) {
		this.submitType = submitType;
	}

}
