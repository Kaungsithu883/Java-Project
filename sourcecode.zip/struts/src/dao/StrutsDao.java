package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StrutsDao {
	// method for create connection
		public static Connection getConnection() throws Exception {
			try {
				Class.forName("com.mysql.jdbc.Driver");
				return DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/struts?useSSL=false", "root", "root");
			} catch (Exception e) {
				e.printStackTrace();  																																											
				return null;
			}
		}

		// method for save user data in database
		public int registerUser(String uname, String fname, String lname, String city, String country, String uemail, String upass, String udeg) throws Exception {
			int i = 0; 
			try {
				String sql = "INSERT INTO struts2crud VALUES (?,?,?,?,?,?,?,?)";
				PreparedStatement ps = getConnection().prepareStatement(sql);
				ps.setString(1, uname);
				ps.setString(2, fname);
				ps.setString(3, lname);
				ps.setString(4, city);
				ps.setString(5, country);
				ps.setString(6, uemail);
				ps.setString(7, upass);
				ps.setString(8, udeg);
				i = ps.executeUpdate();
				return i;
			} catch (Exception e) {
				e.printStackTrace();
				return i;
			} finally {
				if (getConnection() != null) {
					getConnection().close();
				}
			}
		}

		// method for fetch saved user data
		public ResultSet report() throws SQLException, Exception {
			ResultSet rs = null;
			try {
				String sql = "SELECT uname,fname,lname,city,country,uemail,upass,udeg FROM struts2crud";
				PreparedStatement ps = getConnection().prepareStatement(sql);
				rs = ps.executeQuery();
				return rs;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			} finally {
				if (getConnection() != null) {
					getConnection().close();
				}
			}
		}

		// method for fetch old data to be update
		public ResultSet fetchUserDetails(String uemail) throws SQLException, Exception {
			ResultSet rs = null;
			try {
				String sql = "SELECT uname,fname,lname,city,country,uemail,upass,udeg FROM struts2crud WHERE uemail=?";
				PreparedStatement ps = getConnection().prepareStatement(sql);
				ps.setString(1, uemail);
				rs = ps.executeQuery();
				return rs;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			} finally {
				if (getConnection() != null) {
					getConnection().close();
				}
			}
		}

		// method for update new data in database
		public int updateUserDetails(String uname, String fname, String lname, String city, String country, String uemail, String upass, String udeg, String uemailhidden)
				throws SQLException, Exception {
			getConnection().setAutoCommit(false);
			int i = 0;
			try {
				String sql = "UPDATE struts2crud SET uname=?,fname=?,lname=?,city=?,country=?,uemail=?,upass=?,udeg=? WHERE uemail=?";
				PreparedStatement ps = getConnection().prepareStatement(sql);
				ps.setString(1, uname);
				ps.setString(2, fname);
				ps.setString(3, lname);
				ps.setString(4, city);
				ps.setString(5, country);
				ps.setString(6, uemail);
				ps.setString(7, upass);
				ps.setString(8, udeg);
				ps.setString(9, uemailhidden);
				i = ps.executeUpdate();
				return i;
			} catch (Exception e) {
				e.printStackTrace();
				getConnection().rollback();
				return 0;
			} finally {
				if (getConnection() != null) {
					getConnection().close();
				}
			}
		}

		// method for delete the record
		public int deleteUserDetails(String uemail) throws SQLException, Exception {
			getConnection().setAutoCommit(false);
			int i = 0;
			try {
				String sql = "DELETE FROM struts2crud WHERE uemail=?";
				PreparedStatement ps = getConnection().prepareStatement(sql);
				ps.setString(1, uemail);
				i = ps.executeUpdate();
				return i;
			} catch (Exception e) {
				e.printStackTrace();
				getConnection().rollback();
				return 0;
			} finally {
				if (getConnection() != null) {
					getConnection().close();
				}
			}
		}
}
