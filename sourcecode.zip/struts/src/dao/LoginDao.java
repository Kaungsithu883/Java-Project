package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginDao {

	public static boolean validate(String uemail,String upass){
		boolean status=false;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection( "jdbc:mysql://127.0.0.1:3306/struts?useSSL=false", "root", "root");
			PreparedStatement ps=con.prepareStatement("select * from struts2crud where uemail=? and upass=?");
			ps.setString(1,uemail);
			ps.setString(2,upass);
			ResultSet rs=ps.executeQuery();
			status=rs.next();
		}catch(Exception e){e.printStackTrace();}
		return status;
	}
}
