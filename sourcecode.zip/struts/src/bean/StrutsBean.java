package bean;

public class StrutsBean {
	private String uname, fname, lname, city, country, uemail, upass, udeg;
	int srNo;
	
	public int getSrNo() {
		return srNo;
			
	}
	
	public void setSrNo(int SrNo) {
		this.srNo = SrNo;
		
	}
	
	public String getuname() {
		return uname;
			
	}
	
	public void setuname(String uname) {
		this.uname = uname;
		
	}
	
	public String getfname() {
		return fname;
			
	}
	
	public void setfname(String fname) {
		this.fname = fname;
		
	}
	
	public String getlname() {
		return lname;
			
	}
	
	public void setlname(String lname) {
		this.lname = lname;
		
	}
	
	public String getcity() {
		return city;
			
	}
	
	public void setcity(String city) {
		this.city = city;
		
	}
	
	public String getcountry() {
		return country;
			
	}
	
	public void setcountry(String country) {
		this.country = country;
		
	}
	public String getuemail() {
		return uemail;
			
	}
	
	public void setuemail(String uemail) {
		this.uemail = uemail;
		
	}
	public String getupass() {
		return upass;
			
	}
	
	public void setupass(String upass) {
		this.upass = upass;
		
	}
	public String getudeg() {
		return udeg;
			
	}
	
	public void setudeg(String udeg) {
		this.udeg = udeg;
		
	}
	
	
	

}
